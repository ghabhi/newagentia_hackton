# Agentia Hackathon Submission — GradPath

This folder is the self-contained upload package for the Agentia/Copado headless CLI, IDE/MCP, and release workflow. It contains the audited GradPath demo, deployment/configuration assets, and handoff context; the separate OrangeHRM assessment is not included.

## Contents

- `gradpath-agentia/` — web app, API, tests, source-grounded RAG notes, MCP server, Docker files, and app instructions.
- `scripts/` — Windows PowerShell validation, Git remote setup, image build, and context-confirmed Kubernetes deployment helpers.
- `k8s/` — single-replica SQLite sample deployment.
- `.vscode/mcp.json` — IDE MCP stdio server configuration.
- `.github/workflows/gradpath-ci.yml` — tests and browser/MCP checks on GitHub; publishes GHCR images from main/tag pushes after setup.

Start with [the app guide](gradpath-agentia/README.md) and [Agentia handoff context](gradpath-agentia/AGENTIA_CONTEXT.md).

## Windows quickstart

Open a PowerShell terminal in this `agentia` folder:

```powershell
py -3.12 -m venv .\gradpath-agentia\.venv
.\gradpath-agentia\.venv\Scripts\Activate.ps1
python -m pip install -r .\gradpath-agentia\requirements-dev.txt
python -m uvicorn app.main:app --app-dir .\gradpath-agentia --host 127.0.0.1 --port 8000
```

In a second terminal, run `scripts\Validate-GradPath.ps1 -Browser -Mcp`. Or open `http://127.0.0.1:8000`.

## Upload and release

1. Review all files and the security boundaries in the app guide. The app has no authentication; use demo data only and do not expose it publicly as-is.
2. Install Git for Windows and create your own empty repository.
3. Run `scripts\Set-GitRemote.ps1 -RemoteUrl <your HTTPS-or-SSH repository URL>`.
4. Commit/push through your own approved workflow. GitHub Actions will run checks and publish a container image on main/tag pushes when CI is enabled.
5. Configure your cloud/registry and authentication before a live release. Docker, Kubernetes, Git, and Agentia CLI were not available in the authoring environment, so no remote or deployment credentials are included.

Never upload a real API key, `.env`, SQLite runtime data, or personal borrower information. The upload package intentionally excludes those.
