[CmdletBinding()]
param(
    [string]$Image = 'gradpath-agentia:local'
)

$ErrorActionPreference = 'Stop'
if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    throw 'Docker CLI is unavailable. Install Docker Desktop, start its engine, then retry.'
}
$repoRoot = Split-Path -Parent $PSScriptRoot
$dockerfileContext = Join-Path $repoRoot 'gradpath-agentia'
docker build --tag $Image $dockerfileContext
if ($LASTEXITCODE -ne 0) { throw 'Docker image build failed.' }
Write-Host "Built $Image" -ForegroundColor Green
