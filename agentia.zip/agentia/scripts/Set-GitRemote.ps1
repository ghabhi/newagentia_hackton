[CmdletBinding()]
param(
    [Parameter(Mandatory = $true, Position = 0)]
    [ValidatePattern('^(https://|ssh://|git@)[^\s]+$')]
    [string]$RemoteUrl,

    [string]$Name = 'origin'
)

$ErrorActionPreference = 'Stop'
if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
    throw 'Git is not installed or not on PATH. Install Git for Windows, restart PowerShell, then rerun this script.'
}

$repoRoot = Split-Path -Parent $PSScriptRoot
Push-Location $repoRoot
try {
    if (-not (Test-Path (Join-Path $repoRoot '.git'))) {
        git init
        if ($LASTEXITCODE -ne 0) { throw 'git init failed.' }
    }

    $remotes = git remote
    if ($LASTEXITCODE -ne 0) { throw 'Could not inspect Git remotes.' }
    if ($remotes -contains $Name) {
        git remote set-url $Name $RemoteUrl
    }
    else {
        git remote add $Name $RemoteUrl
    }
    if ($LASTEXITCODE -ne 0) { throw "Could not configure remote '$Name'." }

    Write-Host "Configured Git remote '$Name'. Verify it with: git remote -v" -ForegroundColor Green
    Write-Host 'Next: review git status, create a branch, commit, then push only after reviewing the files.'
}
finally {
    Pop-Location
}
