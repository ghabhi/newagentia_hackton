[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^[^\s]+/[^\s]+:.+$')]
    [string]$Image,

    [string]$Namespace = 'gradpath'
)

$ErrorActionPreference = 'Stop'
if (-not (Get-Command kubectl -ErrorAction SilentlyContinue)) {
    throw 'kubectl is unavailable. Install kubectl and configure a trusted Kubernetes context.'
}
$context = kubectl config current-context 2>$null
if ($LASTEXITCODE -ne 0 -or -not $context) { throw 'No Kubernetes context is configured.' }
Write-Host "Target Kubernetes context: $context" -ForegroundColor Yellow
$confirmation = Read-Host "Type the context name to deploy GradPath into namespace '$Namespace'"
if ($confirmation -ne $context) { throw 'Context confirmation did not match; deployment cancelled.' }

$repoRoot = Split-Path -Parent $PSScriptRoot
$manifest = Join-Path $repoRoot 'k8s\gradpath.yaml'
kubectl create namespace $Namespace --dry-run=client -o yaml | kubectl apply -f -
if ($LASTEXITCODE -ne 0) { throw 'Could not create or verify the target namespace.' }
kubectl apply --namespace $Namespace --filename $manifest
if ($LASTEXITCODE -ne 0) { throw 'Could not apply the GradPath Kubernetes resources.' }
kubectl set image --namespace $Namespace deployment/gradpath "gradpath=$Image"
if ($LASTEXITCODE -ne 0) { throw 'Could not update the GradPath image.' }
kubectl rollout status --namespace $Namespace deployment/gradpath --timeout=180s
if ($LASTEXITCODE -ne 0) { throw 'GradPath rollout did not become ready.' }
Write-Host "GradPath deployed to namespace '$Namespace' using $Image" -ForegroundColor Green
Write-Host "For a private registry, create an imagePullSecret and attach it to the deployment service account before rollout."
Write-Host "To test locally: kubectl port-forward --namespace $Namespace service/gradpath 8000:80"
