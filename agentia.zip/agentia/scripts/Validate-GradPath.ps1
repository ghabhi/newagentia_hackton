[CmdletBinding()]
param(
    [switch]$Browser,
    [switch]$Mcp
)

$ErrorActionPreference = 'Stop'
$repoRoot = Split-Path -Parent $PSScriptRoot
$appRoot = Join-Path $repoRoot 'gradpath-agentia'
$env:PYTHONPATH = $appRoot
$python = Get-Command python -ErrorAction SilentlyContinue
if (-not $python) { $python = Get-Command py -ErrorAction SilentlyContinue }
if (-not $python) { throw 'Python 3.11+ is required. Install Python and restart PowerShell.' }

Push-Location $appRoot
try {
    if ($python.Name -eq 'py.exe' -or $python.Name -eq 'py') {
        & $python.Source -3 -m pip install -r requirements-dev.txt
        if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed.' }
        & $python.Source -3 -m pytest -q
        if ($LASTEXITCODE -ne 0) { throw 'GradPath tests failed.' }
        & $python.Source -3 -m compileall -q app scripts
    }
    else {
        & $python.Source -m pip install -r requirements-dev.txt
        if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed.' }
        & $python.Source -m pytest -q
        if ($LASTEXITCODE -ne 0) { throw 'GradPath tests failed.' }
        & $python.Source -m compileall -q app scripts
    }
    if ($LASTEXITCODE -ne 0) { throw 'Python compile check failed.' }

    if ($Browser) {
        if ($python.Name -eq 'py.exe' -or $python.Name -eq 'py') {
            & $python.Source -3 -m playwright install chromium
        }
        else {
            & $python.Source -m playwright install chromium
        }
        if ($LASTEXITCODE -ne 0) { throw 'Could not install Playwright Chromium.' }
        $server = $null
        try {
            $health = Invoke-RestMethod -Uri 'http://127.0.0.1:8000/api/health' -TimeoutSec 2 -ErrorAction Stop
            if ($health.status -ne 'ok') { throw 'GradPath health endpoint returned an unexpected response.' }
        }
        catch {
            if ($python.Name -eq 'py.exe' -or $python.Name -eq 'py') {
                $server = Start-Process -FilePath $python.Source -ArgumentList @('-3', '-m', 'uvicorn', 'app.main:app', '--host', '127.0.0.1', '--port', '8000') -WorkingDirectory $appRoot -PassThru -WindowStyle Hidden
            }
            else {
                $server = Start-Process -FilePath $python.Source -ArgumentList @('-m', 'uvicorn', 'app.main:app', '--host', '127.0.0.1', '--port', '8000') -WorkingDirectory $appRoot -PassThru -WindowStyle Hidden
            }
            try {
                $ready = $false
                for ($attempt = 0; $attempt -lt 30; $attempt++) {
                    try {
                        $health = Invoke-RestMethod -Uri 'http://127.0.0.1:8000/api/health' -TimeoutSec 2 -ErrorAction Stop
                        if ($health.status -eq 'ok') { $ready = $true; break }
                    }
                    catch { Start-Sleep -Milliseconds 500 }
                }
                if (-not $ready) { throw 'Could not start GradPath on port 8000 for the browser test.' }
                $env:GRADPATH_BASE_URL = 'http://127.0.0.1:8000'
                if ($python.Name -eq 'py.exe' -or $python.Name -eq 'py') { & $python.Source -3 .\scripts\check_ui.py }
                else { & $python.Source .\scripts\check_ui.py }
                if ($LASTEXITCODE -ne 0) { throw 'Browser smoke test failed.' }
            }
            finally {
                if ($server -and -not $server.HasExited) { Stop-Process -Id $server.Id -Force -ErrorAction SilentlyContinue }
            }
        }
        if ($server -eq $null) {
            $env:GRADPATH_BASE_URL = 'http://127.0.0.1:8000'
            if ($python.Name -eq 'py.exe' -or $python.Name -eq 'py') { & $python.Source -3 .\scripts\check_ui.py }
            else { & $python.Source .\scripts\check_ui.py }
            if ($LASTEXITCODE -ne 0) { throw 'Browser smoke test failed.' }
        }
    }

    if ($Mcp) {
        if ($python.Name -eq 'py.exe' -or $python.Name -eq 'py') { & $python.Source -3 .\scripts\check_mcp.py }
        else { & $python.Source .\scripts\check_mcp.py }
        if ($LASTEXITCODE -ne 0) { throw 'MCP stdio smoke test failed.' }
    }

    Write-Host 'GradPath validation passed.' -ForegroundColor Green
}
finally {
    Pop-Location
}
