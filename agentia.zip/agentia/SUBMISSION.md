# Agentia Headless Virtual Hackathon — Submission Details

## Submission title
**GradPath: Student Loan Repayment Copilot with Source-Grounded RAG and MCP**

## Problem statement (under 2,000 characters)
Students often face several loans, different interest rates, and confusing repayment information. Comparing payoff strategies manually is error-prone, while general-purpose AI can produce outdated or unsupported guidance. A useful planning tool should make repayment scenarios understandable, show where information comes from, and avoid presenting estimates as financial advice. Developers also need a practical way to build, test, and release such an application using a headless agent workflow, IDE-connected MCP tools, and containerized deployment.

## Abstract (under 4,000 characters)
GradPath is a student-loan planning demo that combines a responsive web application, a deterministic repayment engine, source-grounded student-aid Q&A, and reusable MCP tools. Students can enter loan balances, APRs, and minimum payments; compare avalanche and snowball strategies; test extra monthly payments; inspect a payoff estimate and annual schedule; save scenarios locally; and export a plan as CSV.

For general student-aid questions, GradPath retrieves short, curated notes linked to official Federal Student Aid pages. If configured with a model-provider API key, it can use retrieved passages to generate a concise answer. Without a key—or if the provider is unavailable—it falls back to retrieval-only notes and citations. Loan calculations are always deterministic application code, never LLM output. The app does not determine eligibility, make payments, link servicer accounts, or replace advice from a servicer.

The implementation includes a FastAPI API, SQLite demo persistence, an MCP stdio server with payoff and source-retrieval tools, IDE MCP configuration, automated tests, Playwright browser and MCP smoke checks, Docker/Compose packaging, a Kubernetes example, Windows PowerShell release helpers, and a GitHub Actions workflow for validation and container publishing. Agent instructions, an architecture/context brief, and curated source notes make the product boundaries and retrieval behavior explicit for agent-assisted development.

The package is ready for repository upload and local validation. A public repository, live cloud deployment, recorded demo, and presentation deck still need to be created by the submitter; links below are intentionally marked as pending rather than fabricated.

## Problem solved
- Makes payoff options and the effect of extra payments easier to compare.
- Reduces manual calculation mistakes with a shared deterministic calculator.
- Provides general aid guidance with official-source citations and a retrieval-only fallback.
- Gives IDE/agent hosts reusable MCP tools and a documented CLI-to-CI/container workflow.
- States privacy and financial boundaries: no account linking, payment execution, or eligibility determination.

## Tools and technologies used
- **Application:** Python 3.11+, FastAPI, Pydantic, SQLite, HTML/CSS/JavaScript.
- **Agent and retrieval:** Model Context Protocol Python SDK over stdio; local curated Markdown corpus with lexical/TF-IDF-style retrieval; optional OpenAI Responses API generation when configured.
- **Quality:** pytest, Playwright, Python compile checks; API, browser, and MCP integration checks.
- **Delivery:** Docker, Docker Compose, Kubernetes manifests, PowerShell helper scripts, GitHub Actions, GHCR image publishing workflow.
- **Context engineering:** `AGENTS.md`, `AGENTIA_CONTEXT.md`, architecture/trust-boundary brief, curated source notes, and executable tests.

## Publicly accessible GitHub repository link
**Pending.** No Git remote or public repository has been configured yet. After creating and pushing a public GitHub repository, replace this line with its URL: **[PASTE PUBLIC REPOSITORY URL HERE]**.

## Demo video
**Pending.** Record and upload a walkthrough, then replace with the shareable video URL: **[PASTE DEMO VIDEO URL HERE]**.

Suggested 2–3 minute demo: explain the student problem; compare avalanche/snowball; ask a question and show citations/fallback; invoke both MCP tools from the IDE; run tests with the headless/PowerShell workflow; show the container/CI release path. Do not claim a public deployment unless one has actually been configured and verified.

## Presentation deck
**Pending.** Create/upload the deck and replace with its shareable URL: **[PASTE PRESENTATION DECK URL HERE]**.

Suggested slides: problem and users; GradPath workflow; deterministic calculator + RAG/MCP architecture; context engineering and safety; test/CI/container release path; results and limitations; live demo and next steps.

## Validation completed for this package
The final `Downloads/agentia` package passed 17 automated tests, Python compilation, MCP stdio tool checks, and browser smoke checks in the authoring environment. This does not mean it has been uploaded, publicly released, or deployed to a cloud service.
