# Architecture and Context Brief

## Product

GradPath supports exploratory student-loan payoff comparisons and general source-cited Federal Student Aid questions. It does not link servicer accounts, apply for programs, make payments, or determine personal eligibility.

## Trust boundaries

```mermaid
flowchart LR
  Browser[Browser UI and local draft] -->|same-origin REST| API[FastAPI]
  API --> Core[Deterministic payoff engine]
  API --> RAG[Curated-note retrieval]
  RAG --> Notes[Official-source notes]
  RAG -->|optional excerpts only| Model[Hosted model]
  API --> DB[(SQLite demo plans)]
  IDE[IDE/Agentia host] -->|stdio MCP| MCP[MCP server]
  MCP --> Core
  MCP --> RAG
  CI[GitHub Actions] --> Tests[pytest, browser, MCP]
  CI --> Image[Container publish]
```

- Unsaved drafts remain in browser local storage; saved plans are shared on the local service because demo authentication is not implemented.
- Only `/api/ask` optionally sends a question plus retrieved public excerpts to a hosted model; loan balances are not sent. Provider terms must be reviewed before use.
- MCP runs locally over stdio and exposes deterministic calculator and local-source retrieval only.
- SQLite/Kubernetes runs at one replica. Public deployment requires authentication and managed PostgreSQL.
- Knowledge notes are paraphrased and may become stale; they are not live policy, legal advice, or eligibility guidance.

## RAG process

1. Reviewer adds curated Markdown with title, publisher, HTTPS Federal Student Aid URL.
2. Loader rejects non-`studentaid.gov` links.
3. Local deterministic lexical ranking selects bounded excerpts.
4. Citations include source URL and stable chunk ID.
5. Optional model receives only question plus retrieved public notes and explicit no-invention rules.
6. Missing retrieval/provider failure returns a retrieval-only response with sources where possible.

For a larger corpus, consider managed vector retrieval/pgvector, hybrid search, reranking, ingestion versioning, source freshness monitoring, and a RAG evaluation suite. Current small corpus favors auditable local retrieval over unnecessary infrastructure.

## Context engineering packet

- `AGENTS.md`: durable engineering and safety rules.
- `AGENTIA_CONTEXT.md`: CLI/MCP handoff and acceptance criteria.
- This file: trust and architecture decisions.
- `knowledge/*.md`: reviewed source context.
- `tests/test_app.py`: executable expected behaviors.
- Root `.github/workflows/gradpath-ci.yml`: repeatable quality and image gates.

Hackathon story: use the IDE/MCP tools, ask a general aid question and inspect citations, modify the calculator with context and tests, run headless validation, build an OCI image, then show CI publishing. Do not claim public release without configured Git remote, registry, cloud target, and security controls.
