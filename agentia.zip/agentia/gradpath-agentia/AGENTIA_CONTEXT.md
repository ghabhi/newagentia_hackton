# Agentia / Copado Headless Handoff Context

Use this file when importing this package into Agentia Headless or Copado. Exact vendor CLI commands and flags depend on your installed version/account; inspect that CLI's help and use your configured tenant rather than assuming unsupported commands.

## Mission

Ship a safe student-loan planning demo that combines deterministic payoff calculations, official-source RAG, and MCP tools. Read `AGENTS.md` and `docs/architecture.md` before changing code.

## Tool entry points

- **IDE/MCP:** root `.vscode/mcp.json` launches `app.mcp_server` over stdio. Tools: `calculate_payoff`, `find_official_resources`.
- **Headless validation:** from repo root, `powershell -ExecutionPolicy Bypass -File .\scripts\Validate-GradPath.ps1 -Browser -Mcp`.
- **Docker:** `powershell -ExecutionPolicy Bypass -File .\scripts\Build-GradPathImage.ps1 -Image gradpath-agentia:local`; stack: `docker compose -f .\gradpath-agentia\docker-compose.yml up --build`.
- **Kubernetes:** publish image, then `powershell -ExecutionPolicy Bypass -File .\scripts\Deploy-GradPath.ps1 -Image <registry-owner/gradpath-agentia:tag> -Namespace <namespace>`. Script requires confirming the active cluster context.
- **Git:** create an empty hosted repository, then run `powershell -ExecutionPolicy Bypass -File .\scripts\Set-GitRemote.ps1 -RemoteUrl <HTTPS-or-SSH-repository-url>`. Review files and changes before commit/push.
- **CI/release:** `.github/workflows/gradpath-ci.yml` runs tests, browser/MCP smoke checks, and publishes a GHCR image on main/tag pushes once uploaded to GitHub.

## Acceptance checks

1. `python -m pytest -q` and `python -m compileall -q app scripts` pass.
2. Browser supports calculator, source-cited Q&A, saved plans, CSV download.
3. MCP lists and invokes both tools; invalid input fails safely.
4. Container runs non-root and reports `/api/health`.
5. Kubernetes uses a pinned image tag, one replica with SQLite, persistent storage, and a confirmed private/trusted context.
6. Never call the unauthenticated app production-ready or public. Production needs authentication, TLS, managed secrets, managed PostgreSQL, backups, monitoring, and privacy/retention review.

## Safety

- Never use an LLM for numerical repayment calculation.
- Do not invent policy or determine individual eligibility; cite reviewed Federal Student Aid sources and direct users to their servicer.
- Do not request/log account credentials or personal identifiers. Only `/api/ask` can send the user's question and retrieved public text to the configured model provider.
- Do not modify the unrelated OrangeHRM assessment.
