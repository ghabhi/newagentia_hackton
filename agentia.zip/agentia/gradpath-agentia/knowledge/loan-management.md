---
title: Federal Student Aid — Manage your loans
url: https://studentaid.gov/manage-loans/
publisher: U.S. Federal Student Aid
---
Federal Student Aid provides official account tools and information for managing federal student loans. Use the official account and contact the servicer to review loan details, repayment status, and available actions. Do not share passwords, Social Security numbers, or other sensitive identifiers with this planning app. Confirm balances and terms with the servicer before acting.
