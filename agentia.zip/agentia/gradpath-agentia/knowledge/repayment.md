---
title: Federal Student Aid — Repayment plans
url: https://studentaid.gov/manage-loans/repayment/plans
publisher: U.S. Federal Student Aid
---
Federal student loan repayment options and eligibility depend on a borrower's loans and circumstances. Review current repayment information in the official Federal Student Aid account and confirm available plans, monthly amounts, and application steps with the loan servicer. An estimator is a planning aid, not a loan offer or eligibility decision. Program information can change; check the official source for current details.
