---
title: Federal Student Aid — Public Service Loan Forgiveness
url: https://studentaid.gov/manage-loans/forgiveness-cancellation/public-service
publisher: U.S. Federal Student Aid
---
Public Service Loan Forgiveness (PSLF) is a federal program with specific requirements. Verify current program details, qualifying employment, payment conditions, and application steps on official Federal Student Aid pages. This application does not determine eligibility or certify qualifying payments. Contact official servicer or program channels for individual determinations.
