# GradPath Agentia — Student Aid & Repayment Copilot

A local-first full-stack hackathon app for deterministic loan payoff planning, source-grounded student-aid Q&A, MCP tools, and a GitHub container release flow. It is separate from the OrangeHRM assessment.

## Architecture

- Responsive browser UI served by FastAPI; editable drafts stay in browser local storage.
- Python deterministic payoff engine shared by REST and MCP (no LLM arithmetic).
- Local Markdown source notes, bounded TF-IDF-style retrieval and citations. Optional Responses API generation through `OPENAI_API_KEY`; disabled otherwise. RAG failure falls back to quoted/cited retrieval notes.
- SQLite plan persistence for single-user/demo use.
- MCP stdio tools: `calculate_payoff`, `find_official_resources`.
- Docker/Compose, single-replica Kubernetes sample, GitHub Actions tests and GHCR image publishing.

Read [Agentia handoff](AGENTIA_CONTEXT.md), [architecture](docs/architecture.md), and [agent instructions](AGENTS.md) before extending the app.

## Windows local run

From the folder containing this README in PowerShell:

```powershell
py -3.12 -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements-dev.txt
python -m uvicorn app.main:app --reload
```

Open <http://127.0.0.1:8000>. For reproducible deployment, use Python 3.12. The project declares Python 3.11+.

Optional hosted answer generation: set `OPENAI_API_KEY` and `OPENAI_MODEL` in your environment. A question and retrieved public-source text will be sent to that model provider. Loan balances are not. Without a key, all Q&A stays local. Never submit identifying data or credentials.

## Privacy and security

The question and retrieved public excerpts are sent to the configured model provider when a key is set. The UI discloses this and the API applies a small per-process Q&A rate limit. Do not submit personal identifiers, account credentials, or private financial records to the Q&A. Without credentials, questions stay local.

## Validation

```powershell
python -m pytest -q
python -m compileall -q app scripts
python -m playwright install chromium
python scripts/check_ui.py
python scripts/check_mcp.py
```

 The UI check expects the local server on port 8000. From the package's parent repository, use `scripts/Validate-GradPath.ps1 -Browser -Mcp` to run checks and start/stop a server if needed.

## HTTP API

- `GET /api/health`
- `POST /api/estimate`
- `POST /api/ask`
- `GET /api/resources`
- `GET/POST /api/plans`, `GET/DELETE /api/plans/{plan_id}`
- Interactive API docs: `/docs`

## MCP and IDE

The workspace `.vscode/mcp.json` launches the stdio server from this folder with `PYTHONPATH` configured. Install requirements in the Python interpreter selected in VS Code, then start/reload the MCP server.

## Container and cloud

From this folder:

```powershell
docker compose up --build
```

For GitHub, root `.github/workflows/gradpath-ci.yml` runs tests/browser/MCP checks and publishes a GHCR image on main/tag pushes. Root `scripts/` has Git remote, Docker build, validation, and Kubernetes deploy helpers.

Kubernetes uses SQLite on a persistent volume and one replica. It is a demo, not public-ready: there is no API authentication or authorization. Before public exposure, require auth, TLS, managed secrets, backups, monitoring, privacy/retention review and managed PostgreSQL; pin image tags and configure appropriate network policy.

## Financial boundaries

Estimates assume fixed APRs, monthly interest, and on-time payments. Real loan terms and servicing allocation vary. This educational tool is not financial/legal/tax advice; it does not determine eligibility, make payments, contact servicers, or issue offers. Verify current policy at cited official Federal Student Aid pages and with a servicer. Use fictional demo data only.
