"""Browser workflow smoke check; requires app at localhost:8000."""

from __future__ import annotations

import asyncio
import os
from pathlib import Path

from playwright.async_api import async_playwright


async def main() -> None:
    errors: list[str] = []
    base_url = os.getenv("GRADPATH_BASE_URL", "http://127.0.0.1:8000").rstrip("/")
    async with async_playwright() as playwright:
        browser = await playwright.chromium.launch(headless=True)
        page = await browser.new_page(accept_downloads=True)
        page.on("pageerror", lambda error: errors.append(str(error)))
        await page.goto(base_url, wait_until="networkidle")
        await page.evaluate("localStorage.removeItem('gradpath-agentia-draft-v1')")
        await page.reload(wait_until="networkidle")
        assert await page.title() == "GradPath · Student Loan Copilot"
        assert await page.locator("#total").inner_text() == "$38,100"

        await page.locator("#question").fill("Where can I check federal repayment plan information?")
        await page.locator("#askForm button[type=submit]").click()
        await page.locator("#answer").wait_for(state="visible")
        await page.wait_for_function("!document.querySelector('#answer').innerText.includes('Searching official-source notes')")
        assert "studentaid.gov" in await page.locator("#answer").inner_text()

        async with page.expect_download() as download_info:
            await page.locator("#export").click()
        assert (await download_info.value).suggested_filename == "gradpath-payoff-plan.csv"

        await page.locator("#add").click()
        row = page.locator("#loans .loan-row").last
        await row.locator('[data-key="balance"]').fill("1200")
        await row.locator('[data-key="apr"]').fill("0")
        await row.locator('[data-key="minimum_payment"]').fill("100")
        await page.wait_for_function("document.querySelector('#total').innerText === '$39,300'")

        name = page.locator('#loans .loan-row').first.locator('[data-key="name"]')
        await name.fill('<img src=x onerror=alert(1)>')
        await page.wait_for_timeout(200)
        assert await page.locator('#insights img').count() == 0
        await name.fill('=1+1')
        await page.wait_for_timeout(200)
        async with page.expect_download() as formula_download:
            await page.locator('#export').click()
        csv_path = await (await formula_download.value).path()
        assert "'=1+1" in Path(csv_path).read_text(encoding='utf-8-sig')

        await page.locator('#save').click()
        await page.locator('#planName').fill('Automated smoke plan')
        await page.locator('#saveForm button[type="submit"]').click()
        plan = page.locator('.plan-item').filter(has_text='Automated smoke plan')
        await plan.wait_for()
        await plan.locator('.load-plan').click()
        await page.wait_for_function("document.querySelector('#total').innerText === '$39,300'")
        page.once('dialog', lambda dialog: asyncio.create_task(dialog.accept()))
        await plan.locator('.delete-plan').click()
        await plan.wait_for(state='detached')
        assert not errors, errors
        print("Browser smoke check passed: UI, RAG citations, calculator, CSV safety, saved plans, no JS errors.")
        await browser.close()


if __name__ == "__main__":
    asyncio.run(main())
