"""Record a short GradPath walkthrough to Downloads/agentia/demos as WebM."""

from __future__ import annotations

import asyncio
import shutil
import tempfile
from pathlib import Path

import httpx
from playwright.async_api import async_playwright

APP_ROOT = Path(__file__).resolve().parents[1]
OUTPUT = APP_ROOT.parent / "demos" / "gradpath-walkthrough.webm"
BASE_URL = "http://127.0.0.1:8000"


async def main() -> None:
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    async with httpx.AsyncClient() as client:
        health = await client.get(f"{BASE_URL}/api/health", timeout=3)
        health.raise_for_status()

    with tempfile.TemporaryDirectory(prefix="gradpath-video-") as video_dir:
        async with async_playwright() as playwright:
            browser = await playwright.chromium.launch(headless=True)
            context = await browser.new_context(
                viewport={"width": 1365, "height": 900},
                device_scale_factor=1,
                record_video_dir=video_dir,
                record_video_size={"width": 1365, "height": 900},
                accept_downloads=True,
            )
            page = await context.new_page()
            errors: list[str] = []
            page.on("pageerror", lambda error: errors.append(str(error)))
            await page.goto(BASE_URL, wait_until="networkidle")
            await page.evaluate("localStorage.removeItem('gradpath-agentia-draft-v1')")
            await page.reload(wait_until="networkidle")
            await page.wait_for_function("document.querySelector('#date').innerText !== '—'")
            await page.wait_for_timeout(1600)

            # Demonstrate a changed budget and payoff strategy.
            await page.locator("#extra").fill("250")
            await page.wait_for_timeout(700)
            await page.locator('input[name="strategy"][value="snowball"]').check()
            await page.wait_for_timeout(800)
            await page.locator('input[name="strategy"][value="avalanche"]').check()
            await page.wait_for_timeout(700)

            # Show the source-grounded answer experience.
            await page.locator("#question").fill("Where can I review federal repayment plan information?")
            await page.locator("#askForm button[type=submit]").click()
            await page.wait_for_function("!document.querySelector('#answer').innerText.includes('Searching official-source notes')")
            await page.wait_for_timeout(2200)

            # Save and export a clearly labeled sample scenario, then remove the
            # temporary saved record so the live demo database is left clean.
            await page.locator("#save").click()
            await page.locator("#planName").fill("Demo walkthrough plan")
            await page.locator("#saveForm button[type=submit]").click()
            demo_plan = page.locator(".plan-item").filter(has_text="Demo walkthrough plan")
            await demo_plan.wait_for()
            await page.wait_for_timeout(1000)
            page.once("dialog", lambda dialog: asyncio.create_task(dialog.accept()))
            await demo_plan.locator(".delete-plan").click()
            await demo_plan.wait_for(state="detached")
            async with page.expect_download():
                await page.locator("#export").click()
            await page.wait_for_timeout(1000)

            if errors:
                raise RuntimeError("Browser errors during recording: " + "; ".join(errors))

            video = page.video
            await context.close()  # Finalizes the video file.
            await browser.close()
            if video is None:
                raise RuntimeError("Playwright did not create a recording.")
            shutil.copy2(await video.path(), OUTPUT)

    print(f"Demo video saved: {OUTPUT}")
    print(f"Size: {OUTPUT.stat().st_size:,} bytes")


if __name__ == "__main__":
    asyncio.run(main())
