"""End-to-end stdio MCP smoke check; can be run from any working directory."""

from __future__ import annotations

import asyncio
import json
import os
import sys
from pathlib import Path

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


async def main() -> None:
    project_root = Path(__file__).resolve().parent.parent
    environment = os.environ.copy()
    environment["PYTHONPATH"] = str(project_root)
    parameters = StdioServerParameters(command=sys.executable, args=["-m", "app.mcp_server"], env=environment)
    async with stdio_client(parameters) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            tools = await session.list_tools()
            names = {tool.name for tool in tools.tools}
            assert {"calculate_payoff", "find_official_resources"}.issubset(names), names
            payoff = await session.call_tool("calculate_payoff", {
                "loans": [{"name": "Sample", "balance": 1200, "apr": 0, "minimum_payment": 100}],
                "extra_payment": 50,
            })
            assert not payoff.isError, payoff
            payoff_data = payoff.structuredContent or json.loads(payoff.content[0].text)
            assert payoff_data["months"] == 8 and payoff_data["paid_off"] is True, payoff_data
            invalid = await session.call_tool("calculate_payoff", {
                "loans": [{"name": "Invalid", "balance": -1, "apr": 0, "minimum_payment": 10}],
            })
            assert invalid.isError is True
            resources = await session.call_tool("find_official_resources", {"topic": "repayment"})
            assert not resources.isError, resources
            resources_data = resources.structuredContent or json.loads(resources.content[0].text)
            assert resources_data["resources"], resources_data
            print("MCP stdio smoke check passed: both tools listed; valid and invalid inputs verified.")


if __name__ == "__main__":
    asyncio.run(main())
