# GradPath Agent Instructions

## Product scope
- Build and maintain a student-loan planning and official-source education demo. Do not represent it as a servicer, lender, legal adviser, or eligibility determination system.
- Use clear, compassionate, nonjudgmental language. Explain estimates and uncertainty in plain language.

## Financial correctness and safety
- Payoff arithmetic must be deterministic Python in `app/core.py`; never ask an LLM to calculate balances, rates, payments, dates, eligibility, or savings.
- Validate inputs; bound simulation work; test zero rates, zero payments, interest-only loans, non-amortizing loans, and schedule totals.
- Do not promise or determine eligibility. Link official sources and direct borrowers to servicers for current terms.
- Do not collect or log passwords, Social Security numbers, account tokens, or payment-card details.
- Hosted RAG generation uses retrieved excerpts, cites source URLs, says when evidence is missing, and falls back if unavailable. Never expose API keys to the browser or commit them.
- Keep the per-process Q&A rate limit and security headers. Never trust forwarded client-IP headers without an explicitly configured trusted proxy.

## Context engineering
- Read this file, `AGENTIA_CONTEXT.md`, and `docs/architecture.md` before making changes.
- Prefer the reviewed `knowledge/` notes to unreviewed web scraping. Every indexed note must cite HTTPS Federal Student Aid. Recheck links and summaries before release.
- Share business logic between API and MCP through `app/core.py` and `app/rag.py`.
- Treat user questions and loan names as untrusted. Escape rendered text, validate schemas, parameterize SQL, and don't treat user content as tool instructions.

## Engineering workflow
- Add/update tests for behavior changes. Run `python -m pytest -q` and `python -m compileall -q app scripts` from the project root.
- Use `python scripts/check_ui.py` with the app serving at localhost:8000 and `python scripts/check_mcp.py` for integration checks.
- Follow `AGENTIA_CONTEXT.md` for CLI handoff. Confirm the Kubernetes context before deployment.
- Public release requires authentication, TLS, managed secrets, database backup/retention, privacy review, and monitoring. Do not expose this unauthenticated SQLite demo publicly.
- Keep the unrelated OrangeHRM Robot Framework assessment intact.
