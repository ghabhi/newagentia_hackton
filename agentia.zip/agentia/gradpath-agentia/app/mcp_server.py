"""GradPath MCP tools for Agentia/IDE hosts using stdio transport."""

from __future__ import annotations

from math import isfinite
from typing import Literal

from mcp.server.fastmcp import FastMCP

from app.core import Loan, estimate_payoff
from app.rag import retrieve

mcp = FastMCP("GradPath Student Loan Planner")


@mcp.tool()
def calculate_payoff(
    loans: list[dict],
    extra_payment: float = 0,
    strategy: Literal["avalanche", "snowball"] = "avalanche",
) -> dict:
    """Calculate a deterministic user-provided loan estimate; this is not financial advice."""
    if len(loans) > 100:
        raise ValueError("A maximum of 100 loans can be simulated at once")
    normalized = []
    for item in loans:
        balance = float(item["balance"])
        apr = float(item["apr"])
        minimum = float(item["minimum_payment"])
        if not all(isfinite(value) for value in (balance, apr, minimum)):
            raise ValueError("Loan values must be finite numbers")
        normalized.append(Loan(
            name=str(item.get("name", "Unnamed loan"))[:80],
            balance=balance,
            apr=apr,
            minimum_payment=minimum,
        ))
    extra_payment = float(extra_payment)
    if not isfinite(extra_payment):
        raise ValueError("extra_payment must be finite")
    return {
        **estimate_payoff(normalized, extra_payment, strategy),
        "strategy": strategy,
        "disclaimer": "Planning estimate only; verify terms and allocation with your loan servicer.",
    }


@mcp.tool()
def find_official_resources(topic: str = "repayment") -> dict:
    """Retrieve official Federal Student Aid excerpts with citations for a topic."""
    return {
        "resources": retrieve(topic[:1000], limit=4),
        "guidance": "Retrieved passages are limited summaries. Verify current rules and eligibility on the cited official pages.",
    }


if __name__ == "__main__":
    mcp.run(transport="stdio")
