"""Deterministic loan payoff estimates and official public resource links."""

from __future__ import annotations

from dataclasses import dataclass
from math import isfinite
from typing import Literal

Strategy = Literal["avalanche", "snowball"]
MAX_MONTHS = 1200


@dataclass(frozen=True)
class Loan:
    name: str
    balance: float
    apr: float
    minimum_payment: float


def estimate_payoff(loans: list[Loan], extra_payment: float = 0, strategy: Strategy = "avalanche") -> dict:
    """Simulate monthly interest and payments, rolling freed minimums to active debt."""
    if not isfinite(extra_payment) or extra_payment < 0 or extra_payment > 10_000_000:
        raise ValueError("extra_payment must be a finite amount between zero and 10,000,000")
    if strategy not in ("avalanche", "snowball"):
        raise ValueError("strategy must be avalanche or snowball")
    if len(loans) > 100:
        raise ValueError("A maximum of 100 loans can be simulated at once")

    for loan in loans:
        values = (loan.balance, loan.apr, loan.minimum_payment)
        if not all(isfinite(float(value)) for value in values):
            raise ValueError("Loan values must be finite numbers")
        if not 0 <= loan.balance <= 100_000_000:
            raise ValueError("Loan balance must be between zero and 100,000,000")
        if not 0 <= loan.apr <= 100:
            raise ValueError("APR must be between zero and 100")
        if not 0 <= loan.minimum_payment <= 10_000_000:
            raise ValueError("Minimum payment must be between zero and 10,000,000")

    debts = [
        {
            "name": loan.name,
            "balance": max(0.0, float(loan.balance)),
            "rate": max(0.0, float(loan.apr)) / 1200,
            "minimum": max(0.0, float(loan.minimum_payment)),
        }
        for loan in loans
    ]
    initial_balance = sum(item["balance"] for item in debts)
    minimum_total = sum(item["minimum"] for item in debts)
    if initial_balance <= 0:
        return {
            "initial_balance": 0.0,
            "minimum_monthly_payment": minimum_total,
            "months": 0,
            "total_interest": 0.0,
            "interest_accrued_before_horizon": 0.0,
            "total_paid": 0.0,
            "paid_off": True,
            "schedule": [],
            "balance_history": [0.0],
        }

    def target_order() -> list[dict]:
        active = [item for item in debts if item["balance"] > 0.005]
        if strategy == "snowball":
            return sorted(active, key=lambda item: item["balance"])
        return sorted(active, key=lambda item: item["rate"], reverse=True)

    interest_total = 0.0
    total_paid = 0.0
    year_paid = 0.0
    year_interest = 0.0
    months = 0
    schedule: list[dict] = []
    balance_history = [round(initial_balance, 2)]

    while any(item["balance"] > 0.005 for item in debts) and months < MAX_MONTHS:
        months += 1
        month_interest = 0.0
        month_paid = 0.0
        for item in debts:
            if item["balance"] > 0:
                interest = item["balance"] * item["rate"]
                item["balance"] += interest
                month_interest += interest
        interest_total += month_interest
        year_interest += month_interest

        for item in debts:
            if item["balance"] > 0.005:
                payment = min(item["balance"], item["minimum"])
                item["balance"] -= payment
                month_paid += payment

        available_extra = float(extra_payment)
        for item in target_order():
            if available_extra <= 0.005:
                break
            payment = min(item["balance"], available_extra)
            item["balance"] -= payment
            available_extra -= payment
            month_paid += payment

        # Redirect unspent minimums from paid loans to the next active loan.
        overflow = max(0.0, minimum_total + extra_payment - month_paid)
        for item in target_order():
            if overflow <= 0.005:
                break
            payment = min(item["balance"], overflow)
            item["balance"] -= payment
            overflow -= payment
            month_paid += payment

        total_paid += month_paid
        year_paid += month_paid
        remaining = sum(item["balance"] for item in debts)
        balance_history.append(round(remaining, 2))

        if months % 12 == 0 or remaining <= 0.005:
            schedule.append({
                "year": (months + 11) // 12,
                "paid": round(year_paid, 2),
                "interest": round(year_interest, 2),
                "balance": round(max(0.0, remaining), 2),
                "months_elapsed": months,
            })
            year_paid = 0.0
            year_interest = 0.0

    paid_off = not any(item["balance"] > 0.005 for item in debts)
    return {
        "initial_balance": round(initial_balance, 2),
        "minimum_monthly_payment": round(minimum_total, 2),
        "months": months,
        "total_interest": round(interest_total if paid_off else 0.0, 2),
        "interest_accrued_before_horizon": round(interest_total, 2),
        "total_paid": round(total_paid, 2),
        "paid_off": paid_off,
        "schedule": schedule,
        "balance_history": balance_history,
    }


OFFICIAL_RESOURCES = [
    {
        "title": "Manage your federal student loans",
        "url": "https://studentaid.gov/manage-loans/",
        "publisher": "U.S. Federal Student Aid",
        "summary": "Official account tools and guidance for federal student loan borrowers.",
    },
    {
        "title": "Repayment plans",
        "url": "https://studentaid.gov/manage-loans/repayment/plans",
        "publisher": "U.S. Federal Student Aid",
        "summary": "Review federal repayment plan information and eligibility through the official source.",
    },
    {
        "title": "Public Service Loan Forgiveness",
        "url": "https://studentaid.gov/manage-loans/forgiveness-cancellation/public-service",
        "publisher": "U.S. Federal Student Aid",
        "summary": "Official PSLF program information. Verify current rules and eligibility directly.",
    },
]
