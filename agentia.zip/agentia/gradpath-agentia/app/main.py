"""FastAPI application: repayment API, local SQLite storage, and browser UI."""

from __future__ import annotations

import json
import os
import sqlite3
import threading
import time
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal
from uuid import uuid4

from fastapi import FastAPI, HTTPException, Response
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from app.core import OFFICIAL_RESOURCES, Loan, estimate_payoff
from app.rag import answer_question, retrieve

PROJECT_DIR = Path(__file__).resolve().parent.parent
STATIC_DIR = Path(__file__).resolve().parent / "static"
DEFAULT_DB = PROJECT_DIR / "data" / "gradpath.sqlite3"


class LoanInput(BaseModel):
    name: str = Field(min_length=1, max_length=80)
    balance: float = Field(ge=0, le=100_000_000, allow_inf_nan=False)
    apr: float = Field(ge=0, le=100, allow_inf_nan=False)
    minimum_payment: float = Field(ge=0, le=10_000_000, allow_inf_nan=False)


class EstimateInput(BaseModel):
    loans: list[LoanInput] = Field(max_length=100)
    extra_payment: float = Field(default=0, ge=0, le=10_000_000, allow_inf_nan=False)
    strategy: Literal["avalanche", "snowball"] = "avalanche"


class SavePlanInput(EstimateInput):
    name: str = Field(min_length=1, max_length=80, pattern=r".*\S.*")


class AskInput(BaseModel):
    question: str = Field(min_length=3, max_length=1000)


class InMemoryRateLimiter:
    """Small per-process guard for optional model costs; use a gateway in production."""

    def __init__(self, limit: int = 10, window_seconds: int = 60):
        self.limit = limit
        self.window_seconds = window_seconds
        self._events: dict[str, list[float]] = {}
        self._lock = threading.Lock()

    def allow(self, key: str) -> bool:
        now = time.monotonic()
        cutoff = now - self.window_seconds
        with self._lock:
            if len(self._events) > 10_000:
                self._events = {
                    client: [stamp for stamp in stamps if stamp > cutoff]
                    for client, stamps in self._events.items()
                }
                self._events = {client: stamps for client, stamps in self._events.items() if stamps}
            recent = [stamp for stamp in self._events.get(key, []) if stamp > cutoff]
            if len(recent) >= self.limit:
                self._events[key] = recent
                return False
            recent.append(now)
            self._events[key] = recent
            return True


@contextmanager
def connect_db(db_path: Path):
    db_path.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(db_path)
    connection.row_factory = sqlite3.Row
    try:
        yield connection
        connection.commit()
    finally:
        connection.close()


def init_db(db_path: Path) -> None:
    with connect_db(db_path) as connection:
        connection.execute(
            """CREATE TABLE IF NOT EXISTS plans (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                created_at TEXT NOT NULL,
                payload TEXT NOT NULL,
                estimate TEXT NOT NULL
            )"""
        )


def to_loans(items: list[LoanInput]) -> list[Loan]:
    return [
        Loan(
            name=item.name.strip() or "Unnamed loan",
            balance=item.balance,
            apr=item.apr,
            minimum_payment=item.minimum_payment,
        )
        for item in items
    ]


def create_app(db_path: Path | None = None) -> FastAPI:
    selected_path = Path(os.environ.get("GRADPATH_DB", str(db_path or DEFAULT_DB)))
    init_db(selected_path)
    api = FastAPI(
        title="GradPath Aid & Repayment Copilot",
        version="1.0.0",
        description="A local-first student loan estimator with a deterministic API and MCP tools.",
    )
    api.state.db_path = selected_path
    api.state.ask_limiter = InMemoryRateLimiter(
        limit=max(1, int(os.environ.get("GRADPATH_ASK_RATE_LIMIT", "10"))),
        window_seconds=60,
    )

    @api.get("/", include_in_schema=False)
    def home() -> FileResponse:
        return FileResponse(STATIC_DIR / "index.html")

    @api.get("/api/health")
    def health() -> dict:
        return {"status": "ok", "service": "gradpath"}

    @api.post("/api/estimate")
    def estimate(request: EstimateInput) -> dict:
        result = estimate_payoff(to_loans(request.loans), request.extra_payment, request.strategy)
        return {**result, "strategy": request.strategy, "extra_payment": request.extra_payment}

    @api.get("/api/resources")
    def resources() -> dict:
        return {"resources": OFFICIAL_RESOURCES, "note": "Confirm current eligibility and rules with the official source."}

    @api.post("/api/ask")
    async def ask(request: AskInput) -> dict:
        client_key = "unknown"
        # Use the connection peer address only; never trust forwarded headers
        # unless a separately configured, trusted proxy validates them.
        if request_client := getattr(request, "client", None):
            client_key = request_client.host or client_key
        if not api.state.ask_limiter.allow(client_key):
            raise HTTPException(status_code=429, detail="Question limit reached. Please wait a minute and try again.")
        passages = retrieve(request.question)
        result = await answer_question(request.question, passages)
        return {**result, "disclaimer": "Educational information only; confirm current details with your servicer."}

    @api.get("/api/plans")
    def list_plans() -> dict:
        with connect_db(api.state.db_path) as connection:
            rows = connection.execute("SELECT id, name, created_at, estimate FROM plans ORDER BY created_at DESC").fetchall()
        return {"plans": [
            {"id": row["id"], "name": row["name"], "created_at": row["created_at"], "estimate": json.loads(row["estimate"])}
            for row in rows
        ]}

    @api.post("/api/plans", status_code=201)
    def save_plan(request: SavePlanInput) -> dict:
        clean_name = request.name.strip()
        payload = {
            "loans": [item.model_dump() for item in request.loans],
            "extra_payment": request.extra_payment,
            "strategy": request.strategy,
        }
        result = estimate_payoff(to_loans(request.loans), request.extra_payment, request.strategy)
        plan_id = str(uuid4())
        created_at = datetime.now(timezone.utc).isoformat()
        with connect_db(api.state.db_path) as connection:
            connection.execute(
                "INSERT INTO plans (id, name, created_at, payload, estimate) VALUES (?, ?, ?, ?, ?)",
                (plan_id, clean_name, created_at, json.dumps(payload), json.dumps(result)),
            )
        return {"id": plan_id, "name": clean_name, "created_at": created_at, "payload": payload, "estimate": result}

    @api.get("/api/plans/{plan_id}")
    def get_plan(plan_id: str) -> dict:
        with connect_db(api.state.db_path) as connection:
            row = connection.execute("SELECT * FROM plans WHERE id = ?", (plan_id,)).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail="Plan not found")
        return {
            "id": row["id"], "name": row["name"], "created_at": row["created_at"],
            "payload": json.loads(row["payload"]), "estimate": json.loads(row["estimate"]),
        }

    @api.delete("/api/plans/{plan_id}", status_code=204)
    def delete_plan(plan_id: str) -> Response:
        with connect_db(api.state.db_path) as connection:
            cursor = connection.execute("DELETE FROM plans WHERE id = ?", (plan_id,))
        if cursor.rowcount == 0:
            raise HTTPException(status_code=404, detail="Plan not found")
        return Response(status_code=204)

    return api


app = create_app()
