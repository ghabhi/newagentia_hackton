from fastapi.testclient import TestClient
import pytest

from app.core import Loan, estimate_payoff
from app.main import create_app


def make_client(tmp_path):
    return TestClient(create_app(tmp_path / "test.sqlite3"))


def one_loan(balance=1200, apr=0, minimum=100):
    return {"name": "Test loan", "balance": balance, "apr": apr, "minimum_payment": minimum}


def test_health_and_ui_are_served(tmp_path):
    client = make_client(tmp_path)
    assert client.get("/api/health").json()["status"] == "ok"
    page = client.get("/")
    assert page.status_code == 200
    assert "Make your next money move clearer" in page.text


def test_zero_interest_estimate_and_annual_schedule(tmp_path):
    result = make_client(tmp_path).post("/api/estimate", json={"loans": [one_loan()], "extra_payment": 50}).json()
    assert result["paid_off"] is True
    assert result["months"] == 8
    assert result["total_interest"] == 0
    assert result["schedule"] == [{"year": 1, "paid": 1200, "interest": 0, "balance": 0, "months_elapsed": 8}]
    assert result["balance_history"][-1] == 0


def test_extra_payment_and_strategy_select_target_loan(tmp_path):
    client = make_client(tmp_path)
    loans = [one_loan(1000, 10, 30), {"name": "Small loan", "balance": 500, "apr": 2, "minimum_payment": 30}]
    avalanche = client.post("/api/estimate", json={"loans": loans, "extra_payment": 100, "strategy": "avalanche"}).json()
    snowball = client.post("/api/estimate", json={"loans": loans, "extra_payment": 100, "strategy": "snowball"}).json()
    baseline = client.post("/api/estimate", json={"loans": loans, "extra_payment": 0}).json()
    assert avalanche["paid_off"] and snowball["paid_off"]
    assert avalanche["total_interest"] < baseline["total_interest"]
    assert len(avalanche["balance_history"]) == avalanche["months"] + 1
    assert len(snowball["balance_history"]) == snowball["months"] + 1


def test_non_amortizing_loan_is_flagged(tmp_path):
    result = make_client(tmp_path).post("/api/estimate", json={"loans": [one_loan(1000, 12, 0)]}).json()
    assert result["paid_off"] is False
    assert result["months"] == 1200
    assert result["total_interest"] == 0
    assert result["interest_accrued_before_horizon"] > 1000


def test_interest_only_payment_does_not_report_payoff(tmp_path):
    result = make_client(tmp_path).post("/api/estimate", json={"loans": [one_loan(1000, 12, 10)]}).json()
    assert result["paid_off"] is False
    assert result["months"] == 1200
    assert result["interest_accrued_before_horizon"] == pytest.approx(12000)
    assert result["schedule"][-1]["balance"] == pytest.approx(1000)


def test_zero_payment_does_not_report_false_early_horizon(tmp_path):
    result = make_client(tmp_path).post("/api/estimate", json={"loans": [one_loan(1000, 0, 0)]}).json()
    assert result["paid_off"] is False
    assert result["months"] == 1200


def test_rag_answers_from_retrieved_official_notes(tmp_path, monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    response = make_client(tmp_path).post("/api/ask", json={"question": "Where do I check federal repayment plan information?"})
    assert response.status_code == 200
    result = response.json()
    assert result["mode"] == "retrieval-only"
    assert result["sources"]
    assert all(source["url"].startswith("https://studentaid.gov/") for source in result["sources"])
    assert "repayment" in result["answer"].lower()


def test_unknown_rag_question_does_not_invent_sources(tmp_path, monkeypatch):
    from app import rag
    monkeypatch.setattr(rag, "KNOWLEDGE_DIR", tmp_path / "empty")
    result = make_client(tmp_path).post("/api/ask", json={"question": "What is the weather forecast on Mars?"}).json()
    assert result["sources"] == []
    assert "couldn't find" in result["answer"]


def test_plan_names_are_trimmed_before_persistence(tmp_path):
    response = make_client(tmp_path).post("/api/plans", json={"name": "   Budget plan   ", "loans": [one_loan()]})
    assert response.status_code == 201
    assert response.json()["name"] == "Budget plan"


def test_blank_plan_name_is_rejected(tmp_path):
    response = make_client(tmp_path).post("/api/plans", json={"name": "   ", "loans": [one_loan()]})
    assert response.status_code == 422


@pytest.mark.parametrize(
    "loan,extra",
    [
        (Loan("NaN", float("nan"), 0, 10), 0),
        (Loan("Infinity", float("inf"), 0, 10), 0),
        (Loan("APR", 100, 101, 10), 0),
        (Loan("Negative minimum", 100, 0, -1), 0),
        (Loan("Valid", 100, 0, 10), float("inf")),
    ],
)
def test_core_rejects_non_finite_and_out_of_range_inputs(loan, extra):
    with pytest.raises(ValueError):
        estimate_payoff([loan], extra)


def test_saved_plan_crud_persists_across_app_instances(tmp_path):
    db_path = tmp_path / "plans.sqlite3"
    client = TestClient(create_app(db_path))
    created = client.post("/api/plans", json={"name": "Spring plan", "loans": [one_loan()], "extra_payment": 50})
    assert created.status_code == 201
    plan = created.json()
    assert plan["name"] == "Spring plan"
    assert client.get(f"/api/plans/{plan['id']}").json()["payload"]["extra_payment"] == 50
    assert len(client.get("/api/plans").json()["plans"]) == 1
    reloaded = TestClient(create_app(db_path))
    assert len(reloaded.get("/api/plans").json()["plans"]) == 1
    assert reloaded.delete(f"/api/plans/{plan['id']}").status_code == 204
    assert reloaded.get(f"/api/plans/{plan['id']}").status_code == 404


def test_validation_and_official_resources(tmp_path):
    client = make_client(tmp_path)
    assert client.post("/api/estimate", json={"loans": [one_loan(apr=101)]}).status_code == 422
    resources = client.get("/api/resources").json()["resources"]
    assert resources
    assert all(item["url"].startswith("https://studentaid.gov/") for item in resources)
